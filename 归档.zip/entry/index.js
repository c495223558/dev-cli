let App = require(`../src/component/${process.env.FILE_NAME}.vue`).default
module.exports = App