!(function(){
  window.test=123
})()