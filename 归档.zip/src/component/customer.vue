<template>
  <iframe
    src="https://ba-bi.mamcharge.com/public/dashboard/072acc8d-62f1-4e6b-93a3-794e5a61b1fc"
    height="100%"
    width="100%"
    name="ba-bi"
    scrolling="auto"
    frameborder="0"
    sandbox="allow-same-origin allow-top-navigation allow-forms allow-scripts"
  ></iframe>
</template>
<script>
import Cookies from 'js-cookie'
export default {
  name: 'customer', // 必须
  mounted() {
    console.log(Cookies)
  }
}
</script>